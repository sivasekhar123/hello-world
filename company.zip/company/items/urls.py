from django.conf.urls import url
from .views import *


app_name = 'items'
urlpatterns = [
    url('^team_list/$', team_list, name='team_list'),
    url('^developer_team_list/$', developer_team_list, name='developer_team_list'),
    url('^quality_team_list/$', quality_team_list, name='quality_team_list'),
    url('^support_team_list/$', support_team_list, name='support_team_list'),
    url('^project_list/$', project_list, name='project_list'),
    url('^create_employee/$', create_employee, name='create_employee'),
    url(r'^developer_details/(?P<employee_id>\d+)/$', developer_details, name='developer_details'),
    url(r'^quality_details/(?P<employee_id>\d+)/$', quality_details, name='quality_details'),
    url(r'^support_details/(?P<employee_id>\d+)/$', support_details, name='support_details'),
    url(r'^project_details/(?P<project_id>\d+)/$', project_details, name='project_details'),
    url('^create_project/$', create_project, name='create_project'),
    url('^create_employee_form/$', create_employee_form, name='create_employee_form'),
    url('^create_project_form/$', create_project_form, name='create_project_form'),
]