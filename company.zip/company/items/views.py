# -*- coding: utf-8 -*-
"""
importing to write business logic
"""
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from . models import Employee, Project
from . forms import EmployeeForm, ProjectForm


def team_list(request):
    """
    to display team list
    :param request:
    :return: team list
    """
    return render(request, 'items/team_list.html', {})


def developer_team_list(request):
    """
    for developers
    :param request:
    :return: developer
    """
    developers = Employee.objects.filter(team='developer_team')
    return render(request, 'items/developer_team.html', {'developers': developers})


def quality_team_list(request):
    """
    for testing people
    :param request:
    :return: quality analyst
    """
    quality_analyst = Employee.objects.filter(team='quality_team')
    return render(request, 'items/quality_team.html', {'quality_analyst': quality_analyst})


def support_team_list(request):
    """
    for support people
    :param request:
    :return: support team
    """
    support_list = Employee.objects.filter(team='support_team')
    return render(request, 'items/support_team.html', {'support_list': support_list})


def project_list(request):
    """
    for projects list
    :param request:
    :return: project list
    """
    projects = Project.objects.all()
    return render(request, 'items/project_list.html', {'projects': projects})


def create_employee(request):
    """
    to create employee
    :param request:
    :return:create employee
    """
    if request.method == 'POST':
        Employee.objects.create(
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            email=request.POST['email'],
            mobile=request.POST['mobile'],
            designation=request.POST['designation'],
            salary=request.POST['salary'],
            employee_id=request.POST['employee_id'],
            team=request.POST['team'],
            project=request.POST['project'],
            profile_pic=request.FILES['profile_pic']
        )
        return redirect('/team_list/')
    return render(request, 'items/create_employee.html', {})


def developer_details(request, employee_id):
    """
    developer details
    :param request:
    :param employee_id: id
    :return: details
    """
    details = Employee.objects.get(id=employee_id)
    return render(request, 'items/developer_details.html', {'details': details})


def quality_details(request, employee_id):
    """
    quality details
    :param request:
    :param employee_id: id
    :return: details
    """
    analysts = Employee.objects.get(id=employee_id)
    return render(request, 'items/quality_details.html', {'analysts': analysts})


def support_details(request, employee_id):
    """
    support details
    :param request:
    :param employee_id: id
    :return: details
    """
    associates = Employee.objects.get(id=employee_id)
    return render(request, 'items/support_details.html', {'associates': associates})


def project_details(request, project_id):
    """
    to display project details
    :param request:
    :param project_id: id
    :return: project details
    """
    details = Project.objects.get(id=project_id)
    return render(request, 'items/project_details.html', {'details': details})


def create_project(request):
    """
    to create project
    :param request:
    :return: create project
    """
    if request.method == 'POST':
        Project.objects.create(
            project_name=request.POST['project_name'],
            description=request.POST['description'],
            project_employees=request.POST['project_employees'],
        )
        return redirect('/project_list/')
    return render(request, 'items/create_project.html', {})


def create_employee_form(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/team_list/')
        else:
            return render(request, 'items/create_employee_form.html', {'errors': form.errors})
    else:
        form = EmployeeForm
        return render(request, 'items/create_employee_form.html', {'form': form})


def create_project_form(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/team_list/')
        else:
            return render(request, 'items/create_project_form.html', {'errors': form.errors})
    else:
        form = ProjectForm
        return render(request, 'items/create_project_form.html', {'form': form})
