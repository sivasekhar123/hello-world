# -*- coding: utf-8 -*-
"""
importing for creating tables
"""
from __future__ import unicode_literals

from django.db import models


class Employee(models.Model):
    """
    database for employee
    """
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    email = models.EmailField()
    mobile = models.IntegerField()
    designation = models.CharField(max_length=30)
    salary = models.IntegerField()
    employee_id = models.IntegerField()
    team = models.CharField(max_length=30)
    project = models.CharField(max_length=50)
    profile_pic = models.ImageField(upload_to='media')
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.first_name


class Project(models.Model):
    """
    database for projects
    """
    project_name = models.CharField(max_length=60)
    description = models.CharField(max_length=200)
    project_employees = models.CharField(max_length=500)

    def __str__(self):
        return self.project_name
